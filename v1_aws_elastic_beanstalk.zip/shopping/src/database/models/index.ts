module.exports = {
  // CustomerModel: require("./Customer"),
  // ProductModel: require('./Product'),
  OrderModel: require("./Order"),
  CartModel: require("./Cart"),
  // AddressModel: require("./Address"),
};

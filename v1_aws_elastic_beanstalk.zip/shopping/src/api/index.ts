module.exports = {
  appEvent: require("./app-events"),
  shopping: require("./shopping"),
};

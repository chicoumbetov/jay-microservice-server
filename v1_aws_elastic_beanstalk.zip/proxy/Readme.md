1 worker process can handle only 256 connections.

4 worker processes can handle 1024 connections \* 4 = 4096

server is listening to port 80.

module.exports = {
  products: require("./products"),
  appEvent: require("./app-events"),
  // ! extracted to separate microservice
  // customer: require("./customer"),
  // shopping: require('./shopping')
};
